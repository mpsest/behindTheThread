<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('newsletter', function (Blueprint $table) {
            $table->id();
            $table->string('email', 150)->unique();
            $table->string('token', 64)->unique()->nullable();
        });
    }
    public function down(): void { Schema::dropIfExists('newsletter'); }
};
